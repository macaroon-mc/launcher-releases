#!/bin/sh
# Waits for the launcher to exit, swaps in the new bundle, then starts it again.
# Arguments: <launcher pid> <unpacked bundle> <install dir> <launcher executable>
set -u
pid="$1"
staging="$2"
target="$3"
executable="$4"
log="$(dirname "$0")/update-result.log"
echo "$(date '+%Y-%m-%d %H:%M:%S') helper started" >> "$log"
i=0
while kill -0 "$pid" 2>/dev/null; do
  i=$((i + 1))
  [ "$i" -gt 1200 ] && { echo "launcher did not exit" >> "$log"; exit 1; }
  sleep 0.1
done
if cp -a "$staging"/. "$target"/; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') update applied" >> "$log"
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') copy failed" >> "$log"
fi
rm -rf "$staging"
nohup "$executable" --updated >/dev/null 2>&1 &
