param(
    [Parameter(Mandatory=$true)][string]$Installer,
    [Parameter(Mandatory=$true)][string]$ExpectedHash,
    [Parameter(Mandatory=$true)][long]$ExpectedSize,
    [Parameter(Mandatory=$true)][int]$ParentPid,
    [Parameter(Mandatory=$true)][string]$InstallDir,
    [switch]$NoRelaunch,
    [string]$ReadyFile = '',
    [string]$ReadyToken = ''
)
function Get-InstallerHash([string]$Path) {
    $stream = [System.IO.File]::OpenRead($Path)
    $algorithm = [System.Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}
$ErrorActionPreference = 'Stop'
$updateLog = Join-Path $PSScriptRoot 'update-result.log'
# Installs from before the rename sit in LumoungsLauncher; the update puts the
# launcher in MacaroonLauncher beside it, and the installer clears the old one.
$target = $InstallDir
if ((Split-Path -Leaf $InstallDir) -ieq 'LumoungsLauncher') {
    $target = Join-Path (Split-Path -Parent $InstallDir) 'MacaroonLauncher'
}
# The launcher binary keeps the original name so older updaters can relaunch it.
$launcher = Join-Path $InstallDir 'macaroon.exe'
$resultFile = Join-Path $PSScriptRoot 'update-result.json'
$report = @{ hash = $ExpectedHash; token = $ReadyToken; success = $false; phase = 'starting' }
function Write-UpdateLog([string]$Message) {
    ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message) | Add-Content -LiteralPath $updateLog -Encoding UTF8
}
function Save-UpdateReport {
    $report | ConvertTo-Json | Set-Content -LiteralPath $resultFile -Encoding UTF8
}
try {
    Write-UpdateLog 'Helper started'
    if ((Get-Item -LiteralPath $Installer).Length -ne $ExpectedSize) { throw 'Installer size mismatch' }
    if ((Get-InstallerHash $Installer) -ne $ExpectedHash) { throw 'Installer hash mismatch' }
    if (-not (Test-Path -LiteralPath $launcher)) { throw 'Installed launcher executable not found' }
    $report.phase = 'waiting-for-launcher'
    if ($ReadyFile) {
        @{token=$ReadyToken; parentPid=$ParentPid} | ConvertTo-Json | Set-Content -LiteralPath $ReadyFile -Encoding UTF8
    }
    Write-UpdateLog 'Installer verified; waiting for launcher exit'
    $parent = Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
    if ($parent -and -not $parent.WaitForExit(120000)) { throw 'Launcher did not exit in time' }
    if ((Get-InstallerHash $Installer) -ne $ExpectedHash) { throw 'Installer changed before installation' }
    Write-UpdateLog 'Launcher exited; starting installer'
    $report.phase = 'installing'
    $setupLog = Join-Path $PSScriptRoot 'setup.log'
    $setupArguments = @('/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/SP-', '/NOCANCEL', ('/DIR="' + $target + '"'), ('/LOG="' + $setupLog + '"'))
    $result = Start-Process -FilePath $Installer -WorkingDirectory $PSScriptRoot -ArgumentList $setupArguments -WindowStyle Hidden -Wait -PassThru
    if ($result.ExitCode -ne 0) { throw ('Installer exited with code ' + $result.ExitCode) }
    Write-UpdateLog ('Update completed in ' + $target)
    $report.success = $true
    $report.phase = 'installed'
    Save-UpdateReport
} catch {
    Write-UpdateLog $_.Exception.Message
    $report.error = $_.Exception.Message
    Save-UpdateReport
} finally {
    # After a move the launcher starts from its new folder.
    $moved = Join-Path $target 'macaroon.exe'
    if (Test-Path -LiteralPath $moved) {
        $launcher = $moved
        $InstallDir = $target
    }
    if (-not $NoRelaunch -and -not (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue) -and (Test-Path -LiteralPath $launcher)) {
        try {
            Write-UpdateLog 'Starting launcher'
            $started = Start-Process -FilePath $launcher -WorkingDirectory $InstallDir -ArgumentList '--updated' -PassThru
            if ($started.WaitForExit(1500) -and $started.ExitCode -ne 0) { throw ('Launcher exited immediately: ' + $started.ExitCode) }
            $report.relaunchPid = $started.Id
            $report.phase = 'relaunch-started'
            Write-UpdateLog ('Launcher process started: ' + $started.Id)
        } catch {
            $report.relaunchError = $_.Exception.Message
            $report.phase = 'relaunch-failed'
            Write-UpdateLog ('Launcher relaunch failed: ' + $_.Exception.Message)
        }
    }
    Save-UpdateReport
    if ($ReadyFile -and (Test-Path -LiteralPath $ReadyFile)) { Remove-Item -LiteralPath $ReadyFile -Force }
}
