#!/bin/sh
# Waits for the launcher to exit, swaps in the new app bundle, then opens it.
# Arguments: <launcher pid> <unpacked .app> <installed .app>
set -u
pid="$1"
staged="$2"
target="$3"
log="$(dirname "$0")/update-result.log"
echo "$(date '+%Y-%m-%d %H:%M:%S') helper started" >> "$log"
i=0
while kill -0 "$pid" 2>/dev/null; do
  i=$((i + 1))
  [ "$i" -gt 1200 ] && { echo "launcher did not exit" >> "$log"; exit 1; }
  sleep 0.1
done
# The old bundle stays aside until the new one is fully in place.
backup="$target.previous"
rm -rf "$backup"
if mv "$target" "$backup" && ditto "$staged" "$target"; then
  rm -rf "$backup"
  echo "$(date '+%Y-%m-%d %H:%M:%S') update applied" >> "$log"
else
  rm -rf "$target"
  mv "$backup" "$target"
  echo "$(date '+%Y-%m-%d %H:%M:%S') swap failed; kept the old launcher" >> "$log"
fi
xattr -dr com.apple.quarantine "$target" 2>/dev/null
rm -rf "$(dirname "$staged")"
open "$target" --args --updated
